package com.example.labourgenciologo.database;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class myDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "biosec.db";


    public myDatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Tablas de la base de datos

        db.execSQL("CREATE TABLE ClaveAcceso (" +
                "idClaveAcceso INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "clave TEXT UNIQUE, " +
                "fechaCreacion TIMESTAMP, " +
                "fechaUso TIMESTAMP)");

        db.execSQL("CREATE TABLE UsuarioGeneral (" +
                "idUsuario INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "cedula TEXT, " +
                "nombre TEXT, " +
                "correo TEXT UNIQUE, " +
                "contrasenia TEXT, " +
                "idClaveAcceso INTEGER, " +
                "FOREIGN KEY (idClaveAcceso) REFERENCES ClaveAcceso(idClaveAcceso) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE Sinave (" +
                "idSinave INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "idClaveAcceso INTEGER, " +
                "FOREIGN KEY (idClaveAcceso) REFERENCES ClaveAcceso(idClaveAcceso))");

        db.execSQL("CREATE TABLE Enfermedad (" +
                "idEnfermedad INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT, " +
                "variante TEXT, " +
                "nivel TEXT)");

        db.execSQL("CREATE TABLE InstitucionSanitaria (" +
                "idInstitucion INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT, " +
                "tipoInstitucion TEXT, " +
                "idAdmin INTEGER, " +
                "FOREIGN KEY (idAdmin) REFERENCES UsuarioGeneral(idUsuario) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE Trabajador (" +
                "idTrabajador INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "tipoTrabajador TEXT, " +
                "disponibilidad BOOLEAN, " +
                "idUsuario INTEGER, " +
                "idInstitucion INTEGER, " +
                "FOREIGN KEY (idUsuario) REFERENCES UsuarioGeneral(idUsuario) ON DELETE CASCADE, " +
                "FOREIGN KEY (idInstitucion) REFERENCES InstitucionSanitaria(idInstitucion))");

        db.execSQL("CREATE TABLE ReporteUrgEpid (" +
                "idReporte INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "estatus TEXT, " +
                "nombre TEXT, " +
                "edad INTEGER, " +
                "sexo TEXT, " +
                "direccion TEXT, " +
                "antecedentesM TEXT, " +
                "sintomas TEXT, " +
                "inicioSintomas DATETIME, " +
                "frecuenciaCard INTEGER, " +
                "temperatura INTEGER, " +
                "saturacion INTEGER, " +
                "presionSistolica INTEGER, " +
                "presionDiastolica INTEGER, " +
                "factoresRiesgo TEXT, " +
                "resultadosEstudios TEXT, " +
                "descripcion TEXT, " +
                "idUrgenciologo INTEGER, " +
                "sospechaEnfermedad INTEGER, " +
                "fRedaccion TIMESTAMP, " +
                "fTomado TIMESTAMP, " +
                "FOREIGN KEY (idUrgenciologo) REFERENCES Trabajador(idTrabajador) ON DELETE CASCADE, " +
                "FOREIGN KEY (sospechaEnfermedad) REFERENCES Enfermedad(idEnfermedad))");

        db.execSQL("CREATE TABLE ReporteEpid (" +
                "idReporte INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "evolucion TEXT, " +
                "estatus TEXT, " +
                "fechaContagio DATETIME, " +
                "lugarContagio TEXT , " +
                "viaTransmision TEXT , " +
                "contactosRiesgo TEXT , " +
                "fechaConfirmacion DATETIME , " +
                "tratamiento TEXT , " +
                "descripcion TEXT , " +
                "idEpidemiologo INTEGER, " +
                "enfermedadConfirmada INTEGER , " +
                "lugarAtencion TEXT , " +
                "idReporteUrg INTEGER, " +
                "fRedaccion TIMESTAMP , " +
                "FOREIGN KEY (idEpidemiologo) REFERENCES Trabajador(idTrabajador) ON DELETE CASCADE, " +
                "FOREIGN KEY (enfermedadConfirmada) REFERENCES Enfermedad(idEnfermedad), " +
                "FOREIGN KEY (idReporteUrg) REFERENCES ReporteUrgEpid(idReporte) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE ReporteJurisGen (" +
                "idReporte INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "estatus TEXT, " +
                "casos INTEGER, " +
                "defunciones INTEGER, " +
                "fRedaccion TIMESTAMP, " +
                "metodologia TEXT, " +
                "recursosInvolucrados TEXT, " +
                "resumenCaso TEXT, " +
                "estrategiasPreventivas TEXT, " +
                "epidemiologiaEnfermedad TEXT, " +
                "descripcion TEXT, " +
                "idAgente INTEGER, " +
                "FOREIGN KEY (idAgente) REFERENCES Trabajador(idTrabajador))");

        db.execSQL("CREATE TABLE ReporteJurisIndiv (" +
                "idReporte INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "descripcionCasos TEXT, " +
                "pruebasRealizadas TEXT, " +
                "medidasControl TEXT, " +
                "recursosInvolucrados TEXT, " +
                "resumenCaso TEXT, " +
                "estrategiasPreventivas TEXT, " +
                "epidemiologiaEnfermedad TEXT, " +
                "descripcion TEXT, " +
                "idAgente INTEGER, " +
                "idReporteEpid INTEGER, " +
                "idReporteGen INTEGER, " +
                "fRedaccion TIMESTAMP, " +
                "FOREIGN KEY (idAgente) REFERENCES Trabajador(idTrabajador), " +
                "FOREIGN KEY (idReporteEpid) REFERENCES ReporteEpid(idReporte), " +
                "FOREIGN KEY (idReporteGen) REFERENCES ReporteJurisGen(idReporte))");

        db.execSQL("CREATE TABLE Mision (" +
                "idMision INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "estatus TEXT, " +
                "descripcion TEXT, " +
                "fConclusion TIMESTAMP, " +
                "fCreacion TIMESTAMP, " +
                "idLider INTEGER, " +
                "FOREIGN KEY (idLider) REFERENCES Trabajador(idTrabajador) ON DELETE CASCADE)");

        db.execSQL("CREATE TABLE MisionTrabajador (" +
                "idMisionTrabajador INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "idTrabajador INTEGER, " +
                "idMision INTEGER, " +
                "FOREIGN KEY (idTrabajador) REFERENCES Trabajador(idTrabajador) ON DELETE CASCADE, " +
                "FOREIGN KEY (idMision) REFERENCES Mision(idMision) ON DELETE CASCADE)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Aquí puedes manejar actualizaciones de esquema si cambias las tablas.
        db.execSQL("DROP TABLE IF EXISTS MisionTrabajador");
        db.execSQL("DROP TABLE IF EXISTS Mision");
        db.execSQL("DROP TABLE IF EXISTS ReporteJurisIndiv");
        db.execSQL("DROP TABLE IF EXISTS ReporteJurisGen");
        db.execSQL("DROP TABLE IF EXISTS ReporteEpid");
        db.execSQL("DROP TABLE IF EXISTS ReporteUrgEpid");
        db.execSQL("DROP TABLE IF EXISTS Trabajador");
        db.execSQL("DROP TABLE IF EXISTS InstitucionSanitaria");
        db.execSQL("DROP TABLE IF EXISTS Enfermedad");
        db.execSQL("DROP TABLE IF EXISTS Sinave");
        db.execSQL("DROP TABLE IF EXISTS UsuarioGeneral");
        db.execSQL("DROP TABLE IF EXISTS ClaveAcceso");
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
        db.execSQL("PRAGMA foreign_keys=ON;"); //llaves foraneas
    }

    //Metodos de inicio de sesión y activación de cuenta
    //1.Activación de cuenta
    public void registerNewUser(String userName,int NoCedula,String Hospital,String claveHospital){


    }

}
